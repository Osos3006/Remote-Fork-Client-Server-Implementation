#include <string>
std::string myfork(std::string, int);
